
<?php $__env->startSection('title', 'Đổi mật khẩu'); ?>
<?php $__env->startSection('main'); ?>
<style>
    .form-changepass {
        width: 433px;
        margin: auto;
        margin-top: 25px;
        padding: 22px;
        border: 1px solid #ddd;
    }
    .form-title {
        text-align: center;
    }
</style>
	<div id="wrap-inner">
        <form class="form-changepass" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo $__env->make('errors.note', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <h1 class="form-title">Đổi mật khẩu</h1>
            <div class="form-group">
                <label for="current_password">Mật khẩu hiện tại</label>
                <input type="password" id="current_password" name="current_password" class="form-control" value="<?php echo e(old('current_password')); ?>">
            </div>

            <div class="form-group">
                <label for="new_password">Mật khẩu mới</label>
                <input type="password" id="new_password" name="new_password" class="form-control"  value="<?php echo e(old('new_password')); ?>">
            </div>

            <div class="form-group">
                <label for="new_password_confirmation">Xác nhận mật khẩu mới</label>
                <input type="password" id="new_password_confirmation" name="new_password_confirmation" class="form-control">
            </div>

            <input style="display: flex; cursor: pointer;" type="submit" class="btn btn-primary m-auto" value="Đổi mật khẩu">
        </form>

	</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Webtiembanh\lib\resources\views/frontend/password.blade.php ENDPATH**/ ?>