
<?php $__env->startSection('title', 'Chi tiết sản phẩm'); ?>
<?php $__env->startSection('main'); ?>
<style>
    .favourite_icon {
        float: right;
        cursor: pointer;
        font-size: 25px !important;
    }
    .favourite_icon:hover {
        opacity: 0.8;
    }
    .favorite-text {
        font-size: 16px;
        color: #222;
    }
</style>
	<link rel="stylesheet" href="css/details.css">
	<div id="wrap-inner">
		<div id="product-info">
			<div class="clearfix"></div>
			<h3><?php echo e($product->prod_name); ?></h3>
			<div class="row">
				<div id="product-img" class="col-xs-12 col-sm-12 col-md-3 text-center">
					<img width="210px" src="<?php echo e(asset('lib/storage/app/avatar/'.$product->prod_img)); ?>">
                </div>
				<div id="product-details" class="col-xs-12 col-sm-12 col-md-9">
					<p>Giá: <span class="price"><?php echo e(number_format($product->prod_price,0,',','.' )); ?> VND</span></p>
					<p>Tình trạng: <?php echo e($product->prod_condition); ?></p>
					<p class="add-cart text-center"><a href="<?php echo e(asset('cart/add/' . $product->prod_id)); ?>">Thêm vào giỏ hàng</a></p>
				</div>
			</div>
		</div>
		<div id="product-detail">
			<h3>Chi tiết sản phẩm</h3>
			<p class="text-justify"><?php echo $product->prod_description; ?></p>
		</div>
		<div id="comment">
			<h3>Bình luận</h3>
			<div class="col-md-9 comment">
				<form method="post">
					<?php echo csrf_field(); ?>
					<div class="form-group">
						<label for="email">Email:</label>
						<input required type="email" class="form-control" id="email" name="email">
					</div>
					<div class="form-group">
						<label for="name">Tên:</label>
						<input required type="text" class="form-control" id="name" name="name">
					</div>
					<div class="form-group">
						<label for="cm">Bình luận:</label>
						<textarea required rows="10" id="cm" class="form-control" name="content"></textarea>
					</div>
					<div class="form-group text-right">
						<button type="submit" class="btn btn-default">Gửi</button>
					</div>
				</form>
			</div>
		</div>
		<div id="comment-list">
			<?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<ul>
				<li class="com-title">
					<?php echo e($comment->com_name); ?>

					<br>
					<span><?php echo e(now()->format('d/m/Y')); ?></span>
				</li>
				<li class="com-details">
					<?php echo e($comment->com_content); ?>

				</li>
			</ul>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</div>
	</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Webtiembanh\lib\resources\views/frontend/details.blade.php ENDPATH**/ ?>