
<?php $__env->startSection('title', 'Danh mục sản phẩm'); ?>
<?php $__env->startSection('main'); ?>
	<link rel="stylesheet" href="css/category.css">
	<div id="wrap-inner">
		<div class="products">
			<h3><?php echo e($category->cate_name); ?></h3>
			<div style="gap: 15px;" class="product-list row">
				<?php $__currentLoopData = $product_cate; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prod_cate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<div style="border-radius: 15px;" class="product-item col-md-3 col-sm-6 col-xs-12">
					<a href="#"><img height="150px" src="<?php echo e(asset('lib/storage/app/avatar/'.$prod_cate->prod_img)); ?>" class="img-thumbnail"></a>
					<p><a href="#"><?php echo e($prod_cate->prod_name); ?></a></p>
					<p class="price"><?php echo e(number_format($prod_cate->prod_price,0,',','.' )); ?> VND</p>
					<div class="marsk">
						<a href="<?php echo e(asset('/detail/' . $prod_cate->prod_id)); ?>">Xem chi tiết</a>
					</div>
				</div>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</div>
		</div>

		<div id="pagination">
			<?php echo e($product_cate->links('vendor.pagination.default')); ?>

		</div>
	</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Webtiembanh\lib\resources\views/frontend/category.blade.php ENDPATH**/ ?>